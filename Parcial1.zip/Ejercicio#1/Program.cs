﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] ArregloEnteros = { 9, 4, 8, 2, 7, 3, 10, 1, 5, 9, 6 };

        var numerosMenoresQue6 = ArregloEnteros.Where(numero => numero < 6);
        Console.WriteLine("Números menores que 6:");
        foreach (var numero in numerosMenoresQue6)
        {
            Console.WriteLine(numero);
        }
    }
}
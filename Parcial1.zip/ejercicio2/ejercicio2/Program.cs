﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] numerosDel1Al20 = Enumerable.Range(1, 20).ToArray();


        var numerosPares = numerosDel1Al20.Where(numero => numero % 2 == 0).ToArray();
        var numerosNoPares = numerosDel1Al20.Where(numero => numero % 2 != 0).ToArray();


        Console.WriteLine("Números que si son pares del 1 al 20:");
        foreach (var numero in numerosPares)
        {
            Console.WriteLine(numero);
        }

        Console.WriteLine("\nNúmeros que no pares del 1 al 20:");
        foreach (var numero in numerosNoPares)
        {
            Console.WriteLine(numero);
        }
    }
}
